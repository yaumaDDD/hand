-- Z-City Appearance Fix Addon (v2)
--
-- What this does:
--   * Provides AppAddModel / AddFacemap / AppAddClothes / AppAddClothesDesc / AppAddBodygroup
--     no matter which addon loads first (fixes "attempt to call global 'AppAddModel' (a nil value)").
--   * Remembers every registration and re-applies it after the gamemode finishes loading,
--     so nothing is lost if the core appearance system resets its tables later.
--   * Only fills in MISSING core functions. It no longer replaces Z-City's own
--     ApplyAppearance / validators / net receivers (that was breaking HL2 Coop).
--
-- If you ever need the old "replace everything" behaviour on a dedicated server,
-- set FORCE_OVERRIDE_CORE to true.

local VERSION = "2.0"
local FORCE_OVERRIDE_CORE = false

hg = hg or {}
hg.Appearance = hg.Appearance or {}
local AP = hg.Appearance

hg.AppearanceFix = hg.AppearanceFix or {}
local Fix = hg.AppearanceFix
Fix.Version = VERSION
Fix.Order = Fix.Order or {}
Fix.Data = Fix.Data or {}

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
local function EnsureTables()
	AP.PlayerModels = AP.PlayerModels or {}
	AP.PlayerModels[1] = AP.PlayerModels[1] or {}
	AP.PlayerModels[2] = AP.PlayerModels[2] or {}

	AP.FuckYouModels = AP.FuckYouModels or {}
	AP.FuckYouModels[1] = AP.FuckYouModels[1] or {}
	AP.FuckYouModels[2] = AP.FuckYouModels[2] or {}

	AP.FacemapsSlots = AP.FacemapsSlots or {}
	AP.FacemapsModels = AP.FacemapsModels or {}
	AP.Bodygroups = AP.Bodygroups or {}
	AP.ValidateFunctions = AP.ValidateFunctions or {}

	AP.Clothes = AP.Clothes or {}
	AP.Clothes[1] = AP.Clothes[1] or {}
	AP.Clothes[2] = AP.Clothes[2] or {}

	AP.ClothesDesc = AP.ClothesDesc or {}
end
EnsureTables()

-- ---------------------------------------------------------------------------
-- Raw registration (writes straight into the tables)
-- ---------------------------------------------------------------------------
local function RawAddModel(strName, strMdl, bFemale, tSubmaterialSlots)
	EnsureTables()
	local idx = bFemale and 2 or 1
	local entry = {
		mdl = strMdl,
		submatSlots = tSubmaterialSlots,
		sex = bFemale
	}
	AP.PlayerModels[idx][strName] = entry
	AP.FuckYouModels[idx][strMdl] = entry
end

local function RawAddFacemap(matOverride, strName, matMaterial, model)
	EnsureTables()
	AP.FacemapsSlots[matOverride] = AP.FacemapsSlots[matOverride] or {}
	AP.FacemapsSlots[matOverride][strName] = matMaterial
	if model then
		AP.FacemapsModels[model] = matOverride
	end
end

local function RawAddClothes(sex, name, path, description, link)
	EnsureTables()
	local idx = (sex == "female" or sex == 2 or sex == true) and 2 or 1
	AP.Clothes[idx][name] = path
	if description or link then
		AP.ClothesDesc[name] = {
			desc = description or "No description provided.",
			link = link
		}
	end
end

local function RawAddClothesDesc(name, tbl)
	EnsureTables()
	AP.ClothesDesc[name] = tbl
end

local function RawAddBodygroup(strBodyGroup, strName, strStringID, bFemale, bPointShop, bDonateOnly, fCost, psModel, psBodygroups, psSubmats, psStrNameOveride)
	EnsureTables()
	local idx = bFemale and 2 or 1
	local pointShopID = "Standard_BodyGroups_" .. (psStrNameOveride or strName)

	AP.Bodygroups[strBodyGroup] = AP.Bodygroups[strBodyGroup] or {}
	AP.Bodygroups[strBodyGroup][idx] = AP.Bodygroups[strBodyGroup][idx] or {}
	AP.Bodygroups[strBodyGroup][idx][strName] = {
		strStringID,
		bPointShop,
		ID = pointShopID
	}

	local PSmodule = hg.PointShop
	if SERVER and PSmodule and PSmodule.CreateItem and not (PSmodule.Items and PSmodule.Items[pointShopID]) then
		PSmodule:CreateItem(pointShopID, string.NiceName(strName), psModel or "models/zcity/gloves/degloves.mdl", psBodygroups, 0, Vector(0, 0, 0), fCost, bDonateOnly, psSubmats or {})
	end
end

-- ---------------------------------------------------------------------------
-- Remembered registration (what other addons actually call)
-- ---------------------------------------------------------------------------
local function Register(key, raw, ...)
	if not Fix.Data[key] then
		Fix.Order[#Fix.Order + 1] = key
	end
	Fix.Data[key] = { raw = raw, args = { n = select("#", ...), ... } }
	raw(...)
end

function Fix.AddModel(strName, strMdl, bFemale, tSubmaterialSlots)
	Register("model|" .. (bFemale and 2 or 1) .. "|" .. tostring(strName), RawAddModel, strName, strMdl, bFemale, tSubmaterialSlots)
end

function Fix.AddFacemap(matOverride, strName, matMaterial, model)
	Register("face|" .. tostring(matOverride) .. "|" .. tostring(strName) .. "|" .. tostring(model), RawAddFacemap, matOverride, strName, matMaterial, model)
end

function Fix.AddClothes(sex, name, path, description, link)
	local idx = (sex == "female" or sex == 2 or sex == true) and 2 or 1
	Register("cloth|" .. idx .. "|" .. tostring(name), RawAddClothes, sex, name, path, description, link)
end

function Fix.AddClothesDesc(name, tbl)
	Register("clothdesc|" .. tostring(name), RawAddClothesDesc, name, tbl)
end

function Fix.AddBodygroup(strBodyGroup, strName, strStringID, bFemale, ...)
	Register("bg|" .. tostring(strBodyGroup) .. "|" .. (bFemale and 2 or 1) .. "|" .. tostring(strName), RawAddBodygroup, strBodyGroup, strName, strStringID, bFemale, ...)
end

function Fix.Replay()
	EnsureTables()
	for _, key in ipairs(Fix.Order) do
		local entry = Fix.Data[key]
		if entry then
			local ok, err = pcall(entry.raw, unpack(entry.args, 1, entry.args.n))
			if not ok then
				ErrorNoHalt("[Z-City Appearance Fix] Replay failed for " .. key .. ": " .. tostring(err) .. "\n")
			end
		end
	end
end

-- Publish the API (globals + hg.Appearance) so older addons written against the
-- original global functions keep working.
local function Publish(globalName, fn, fixName)
	Fix[fixName] = fn
	AP[globalName] = fn
	_G[globalName] = fn
end
Publish("AppAddModel", Fix.AddModel, "AddModel")
Publish("AddFacemap", Fix.AddFacemap, "AddFacemap")
Publish("AppAddClothes", Fix.AddClothes, "AddClothes")
Publish("AppAddClothesDesc", Fix.AddClothesDesc, "AddClothesDesc")
Publish("AppAddBodygroup", Fix.AddBodygroup, "AddBodygroup")

-- ---------------------------------------------------------------------------
-- Fallbacks: only used when Z-City's own versions are missing
-- ---------------------------------------------------------------------------
local function Provide(tbl, key, fn)
	if FORCE_OVERRIDE_CORE or tbl[key] == nil then
		tbl[key] = fn
	end
end

local function SafeCheck(fn, val)
	local ok, result = pcall(fn, val)
	if ok then return result end
	return true
end

Provide(AP.ValidateFunctions, "AModel", function(str)
	if not isstring(str) then return false end
	if table.IsEmpty(AP.PlayerModels[1]) then return true end
	return AP.PlayerModels[1][str] ~= nil or AP.PlayerModels[2][str] ~= nil
end)
Provide(AP.ValidateFunctions, "AClothes", function(tbl) return istable(tbl) end)
Provide(AP.ValidateFunctions, "AName", function(str) return isstring(str) end)
Provide(AP.ValidateFunctions, "AColor", function(clr) return istable(clr) end)
Provide(AP.ValidateFunctions, "AAttachments", function(tbl) return istable(tbl) end)
Provide(AP.ValidateFunctions, "ABodygroups", function(tbl) return istable(tbl) end)
Provide(AP.ValidateFunctions, "AFacemap", function(str) return isstring(str) end)

Provide(AP, "AppearanceValidater", function(tblAppearance)
	if not istable(tblAppearance) then return false end
	local funcs = AP.ValidateFunctions
	for _, key in ipairs({ "AModel", "AClothes", "AName" }) do
		if funcs[key] and not SafeCheck(funcs[key], tblAppearance[key]) then
			return false
		end
	end
	return true
end)

if SERVER then
	util.AddNetworkString("Get_Appearance")
	util.AddNetworkString("OnlyGet_Appearance")

	AP.RandomNames = AP.RandomNames or {
		[1] = { "John Doe", "James Smith", "Robert Miller", "Michael Brown" },
		[2] = { "Jane Doe", "Mary Smith", "Patricia Miller", "Linda Brown" }
	}

	Provide(AP, "GenerateRandomName", function(iSex)
		local names = AP.RandomNames[iSex or math.random(1, 2)] or AP.RandomNames[1]
		return names[math.random(1, #names)]
	end)

	local function ResolveModel(ply, name)
		return AP.PlayerModels[1][name] or AP.PlayerModels[2][name] or name
	end

	Provide(AP, "CheckAttachments", function(ply, tbl)
		if not IsValid(ply) or not ply:IsPlayer() or not tbl then return tbl end
		if AP.GetAccessToAll and AP.GetAccessToAll(ply) then return tbl end

		local PSmodule = hg.PointShop
		if tbl.AAttachments then
			for i = 1, #tbl.AAttachments do
				local uid = tbl.AAttachments[i]
				if not uid or uid == "" or uid == "none" then continue end
				if PSmodule and PSmodule.Items and PSmodule.Items[uid] and ply.PS_HasItem and not ply:PS_HasItem(uid) then
					tbl.AAttachments[i] = ""
				end
				if hg.Accessories and hg.Accessories[uid] and hg.Accessories[uid].disallowinappearance then
					tbl.AAttachments[i] = ""
				end
			end
		end

		local tMdl = ResolveModel(ply, tbl.AModel)
		local sexIdx = (istable(tMdl) and tMdl.sex) and 2 or 1
		tbl.ABodygroups = tbl.ABodygroups or {}

		for k, v in pairs(tbl.ABodygroups) do
			local group = AP.Bodygroups[k] and AP.Bodygroups[k][sexIdx]
			local bodygroup = group and group[v]
			if not bodygroup then continue end

			local uid = bodygroup.ID
			if bodygroup[2] and uid and PSmodule and PSmodule.Items and PSmodule.Items[uid] and ply.PS_HasItem and not ply:PS_HasItem(uid) then
				tbl.ABodygroups[k] = nil
			end
		end

		return tbl
	end)

	Provide(AP, "ForceApplyAppearance", function(ply, tbl, noModelChange)
		if not IsValid(ply) or not tbl then return end

		local tMdl = ResolveModel(ply, tbl.AModel)
		local mdl = istable(tMdl) and tMdl.mdl or tMdl
		local sexIdx = (istable(tMdl) and tMdl.sex) and 2 or 1

		if isstring(mdl) and mdl ~= "" and mdl ~= ply:GetModel() and not noModelChange then
			ply:SetModel(mdl)
		end

		local clr = tbl.AColor
		if istable(clr) and clr.r and clr.g and clr.b then
			local vec = Vector(clr.r / 255, clr.g / 255, clr.b / 255)
			if ply.SetPlayerColor then ply:SetPlayerColor(vec) end
			ply:SetNWVector("PlayerColor", vec)
		end

		ply:SetSubMaterial()
		local mats = ply:GetMaterials()

		if istable(tMdl) and tMdl.submatSlots then
			local clothesTable = AP.Clothes[sexIdx]
			for k, v in pairs(tMdl.submatSlots) do
				local slot = -1
				for i = 1, #mats do
					if mats[i] == v then slot = i - 1 break end
				end

				if slot ~= -1 then
					local clothName = (tbl.AClothes and tbl.AClothes[k]) or "normal"
					local mat = clothesTable[clothName] or clothesTable["normal"]
					if mat then ply:SetSubMaterial(slot, mat) end
					ply:SetNWString("Colthes" .. k, clothName)
				end
			end
		end

		if tbl.AFacemap then
			for i = 1, #mats do
				local map = AP.FacemapsSlots[mats[i]]
				if map and map[tbl.AFacemap] then
					ply:SetSubMaterial(i - 1, map[tbl.AFacemap])
				end
			end
		end

		if tbl.AName then
			ply:SetNWString("PlayerName", tbl.AName)
		end

		ply:SetBodyGroups("00000000000000000000")
		tbl.ABodygroups = tbl.ABodygroups or {}
		for k, v in ipairs(ply:GetBodyGroups()) do
			local chosen = v.name and tbl.ABodygroups[v.name]
			local bgTable = chosen and AP.Bodygroups[v.name]
			local sexTable = bgTable and bgTable[sexIdx]
			local data = sexTable and sexTable[chosen]
			if not data then continue end

			for i = 0, #v.submodels do
				if data[1] == v.submodels[i] then
					ply:SetBodygroup(k - 1, i)
					break
				end
			end
		end

		if ply.SetNetVar then ply:SetNetVar("Accessories", tbl.AAttachments or {}) end
		ply.CurAppearance = table.Copy(tbl)
	end)

	Provide(AP, "GetRandomAppearance", function()
		local iSex = math.random(1, 2)
		local models = AP.PlayerModels[iSex]
		local modelName

		if models and not table.IsEmpty(models) then
			-- table.Random returns (value, key): the key is the model's name
			local _
			_, modelName = table.Random(models)
		end
		modelName = modelName or (iSex == 1 and "Male 01" or "Female 01")

		local clothes = AP.Clothes[iSex]
		local clothName = "normal"
		if clothes and not table.IsEmpty(clothes) then
			local _
			_, clothName = table.Random(clothes)
		end

		return {
			AModel = modelName,
			AClothes = { main = clothName, pants = "normal", boots = "normal" },
			AName = AP.GenerateRandomName(iSex),
			AColor = Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)),
			AAttachments = {},
			ABodygroups = {},
			AFacemap = "Default"
		}
	end)

	local tWaitResponse = {}
	hook.Add("PlayerDisconnected", "ZCityAppearanceFix_Cleanup", function(ply)
		tWaitResponse[ply] = nil
	end)

	local function WearAppearance(ply, tbl)
		if not IsValid(ply) or not tbl then return end
		AP.ForceApplyAppearance(ply, AP.CheckAttachments(ply, tbl))
	end

	local function FallbackApplyAppearance(Client, tAppearance, bRandom, bResponeIsValid, bUseCahsed)
		if not IsValid(Client) then return end

		if bRandom or (Client.IsBot and Client:IsBot()) then
			WearAppearance(Client, AP.GetRandomAppearance())
			return
		end

		if bUseCahsed then
			tAppearance = Client.CachedAppearance
			if not tAppearance or not AP.AppearanceValidater(tAppearance) then
				tAppearance = AP.GetRandomAppearance()
			end
			net.Start("OnlyGet_Appearance")
			net.Send(Client)
			WearAppearance(Client, tAppearance)
			return
		end

		if not bResponeIsValid then
			tWaitResponse[Client] = CurTime() + 3
			net.Start("Get_Appearance")
			net.Send(Client)
			return
		end

		if not tWaitResponse[Client] or tWaitResponse[Client] < CurTime()
			or not tAppearance or not AP.AppearanceValidater(tAppearance) then
			WearAppearance(Client, AP.GetRandomAppearance())
			return
		end

		WearAppearance(Client, tAppearance)
	end

	if FORCE_OVERRIDE_CORE or not isfunction(ApplyAppearance) then
		ApplyAppearance = FallbackApplyAppearance
	end
	Provide(AP, "ApplyAppearance", ApplyAppearance)

	-- Only register receivers if Z-City hasn't already
	if FORCE_OVERRIDE_CORE or not net.Receivers["get_appearance"] then
		net.Receive("Get_Appearance", function(len, client)
			if not IsValid(client) then return end
			local tAppearance = net.ReadTable()
			local bRandom = net.ReadBool()
			if not AP.AppearanceValidater(tAppearance) then bRandom = true end
			ApplyAppearance(client, tAppearance, (table.IsEmpty(tAppearance or {})) or bRandom, true)
		end)
	end

	if FORCE_OVERRIDE_CORE or not net.Receivers["onlyget_appearance"] then
		net.Receive("OnlyGet_Appearance", function(len, client)
			if not IsValid(client) then return end
			local tAppearance = net.ReadTable()
			if not tAppearance or table.IsEmpty(tAppearance) then
				client.CachedAppearance = AP.GetRandomAppearance()
			else
				client.CachedAppearance = tAppearance
			end
		end)
	end

	if FORCE_OVERRIDE_CORE or not isfunction(ApplyAppearanceRagdoll) then
		function ApplyAppearanceRagdoll(ent, ply)
			if not IsValid(ent) or not IsValid(ply) then return end
			local Appearance = ply.CurAppearance
			if not Appearance then return end

			ent:SetNWString("PlayerName", ply:GetNWString("PlayerName", Appearance.AName or ""))
			if ent.SetNetVar and ply.GetNetVar then
				ent:SetNetVar("Accessories", ply:GetNetVar("Accessories", {}))
			end

			local tMdl = AP.FuckYouModels[1][ent:GetModel()] or AP.FuckYouModels[2][ent:GetModel()]
			if not istable(tMdl) then return end

			local mats = ent:GetMaterials()
			local sexIdx = tMdl.sex and 2 or 1
			local clothesTable = AP.Clothes[sexIdx]

			for k, v in pairs(tMdl.submatSlots or {}) do
				local clothName = ply:GetNWString("Colthes" .. k, "normal")
				ent:SetNWString("Colthes" .. k, clothName)

				for i = 1, #mats do
					if mats[i] == v then
						local mat = clothesTable[clothName] or clothesTable["normal"]
						if mat then ent:SetSubMaterial(i - 1, mat) end
						break
					end
				end
			end

			local facemap = Appearance.AFacemap or "Default"
			for i = 1, #mats do
				local map = AP.FacemapsSlots[mats[i]]
				if map and map[facemap] then
					ent:SetSubMaterial(i - 1, map[facemap])
				end
			end
		end
	end
	Provide(AP, "ApplyAppearanceRagdoll", ApplyAppearanceRagdoll)
end

-- ---------------------------------------------------------------------------
-- Re-apply everything once the gamemode is up (cheap and idempotent)
-- ---------------------------------------------------------------------------
local function ReplayAll()
	Fix.Replay()
end
hook.Add("Initialize", "ZCityAppearanceFix_Initialize", ReplayAll)
hook.Add("PostGamemodeLoaded", "ZCityAppearanceFix_PostGM", ReplayAll)
hook.Add("InitPostEntity", "ZCityAppearanceFix_PostEntity", ReplayAll)

-- ---------------------------------------------------------------------------
-- Keep the player's own appearance when a gamemode asks for a random one
-- (Event / Superfighters / Deathmatch etc.). Disable with: zcity_appfix_keep_appearance 0
-- ---------------------------------------------------------------------------
if SERVER then
	local cvKeep = CreateConVar("zcity_appfix_keep_appearance", "1", FCVAR_ARCHIVE,
		"Keep a player's saved appearance when a gamemode requests a random one")

	local function InstallKeepWrapper()
		local orig = ApplyAppearance
		if not isfunction(orig) or Fix.KeepWrapper == orig then return end

		local function wrapped(Client, tAppearance, bRandom, ...)
			if bRandom and cvKeep:GetBool() and IsValid(Client) and Client:IsPlayer() and not Client:IsBot()
				and isfunction(AP.ForceApplyAppearance) then
				local saved = Client.CachedAppearance or Client.CurAppearance
				if istable(saved) and AP.AppearanceValidater(saved) then
					local copy = table.Copy(saved)
					if isfunction(AP.CheckAttachments) then copy = AP.CheckAttachments(Client, copy) end
					AP.ForceApplyAppearance(Client, copy)
					return
				end
			end
			return orig(Client, tAppearance, bRandom, ...)
		end

		Fix.KeepWrapper = wrapped
		ApplyAppearance = wrapped
		AP.ApplyAppearance = wrapped
	end

	hook.Add("InitPostEntity", "ZCityAppearanceFix_KeepWrap", function()
		timer.Simple(1, InstallKeepWrapper)
	end)
	hook.Add("PostGamemodeLoaded", "ZCityAppearanceFix_KeepWrap", function()
		timer.Simple(1, InstallKeepWrapper)
	end)
end

print("[Z-City Appearance Fix] v" .. VERSION .. " loaded (" .. (SERVER and "server" or "client") .. ")")
