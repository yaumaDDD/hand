-- Z-City Appearance Fix Addon
-- This script fixes core issues with the appearance system and ensures Dedicated Server compatibility.

print("[Z-City Appearance Fix] Initializing core engine...")

hg.Appearance = hg.Appearance or {}
local APmodule = hg.Appearance

-- Ensure sub-tables exist and are "sticky"
local function SetupTables()
	APmodule.PlayerModels = APmodule.PlayerModels or {[1] = {}, [2] = {}}
	APmodule.FuckYouModels = APmodule.FuckYouModels or {{}, {}}
	APmodule.FacemapsSlots = APmodule.FacemapsSlots or {}
	APmodule.FacemapsModels = APmodule.FacemapsModels or {}
	APmodule.Bodygroups = APmodule.Bodygroups or {}
	APmodule.ValidateFunctions = APmodule.ValidateFunctions or {}
	APmodule.Clothes = APmodule.Clothes or {[1] = {}, [2] = {}}
	APmodule.ClothesDesc = APmodule.ClothesDesc or {}
end
SetupTables()

-- Redefine registration functions to be global, additive, and persistent
local function OverwriteRegistration()
	function AppAddModel(strName, strMdl, bFemale, tSubmaterialSlots)
		SetupTables()
		APmodule.PlayerModels[bFemale and 2 or 1][strName] = {
			mdl = strMdl,
			submatSlots = tSubmaterialSlots,
			sex = bFemale
		}
		APmodule.FuckYouModels[bFemale and 2 or 1][strMdl] = APmodule.PlayerModels[bFemale and 2 or 1][strName]
	end
	APmodule.AppAddModel = AppAddModel

	function AddFacemap(matOverride, strName, matMaterial, model)
		SetupTables()
		APmodule.FacemapsSlots[matOverride] = APmodule.FacemapsSlots[matOverride] or {}
		local tbl = APmodule.FacemapsSlots[matOverride]
		tbl[strName] = matMaterial
		if model then 
			APmodule.FacemapsModels[model] = matOverride 
		end
	end
	APmodule.AddFacemap = AddFacemap

	function AppAddClothes(sex, name, path, description, link)
		SetupTables()
		local sexIdx = (sex == "female" or sex == 2) and 2 or 1
		APmodule.Clothes[sexIdx][name] = path
		if description or link then
			APmodule.ClothesDesc[name] = {
				desc = description or "No description provided.",
				link = link
			}
		end
	end
	APmodule.AppAddClothes = AppAddClothes

	function AppAddBodygroup(strBodyGroup, strName, strStringID, bFemale, bPointShop, bDonateOnly, fCost, psModel, psBodygroups, psSubmats, psStrNameOveride)
		SetupTables()
		local PSmodule = hg.PointShop
		local pointShopID = "Standard_BodyGroups_" .. (psStrNameOveride or strName)
		APmodule.Bodygroups[strBodyGroup] = APmodule.Bodygroups[strBodyGroup] or {}
		APmodule.Bodygroups[strBodyGroup][bFemale and 2 or 1] = APmodule.Bodygroups[strBodyGroup][bFemale and 2 or 1] or {}
		APmodule.Bodygroups[strBodyGroup][bFemale and 2 or 1][strName] = {
			strStringID,
			bPointShop,
			ID = pointShopID
		}

		if SERVER and PSmodule and PSmodule.CreateItem then
			PSmodule:CreateItem(pointShopID, string.NiceName(strName), psModel or "models/zcity/gloves/degloves.mdl", psBodygroups, 0, Vector(0, 0, 0), fCost, bDonateOnly, psSubmats or {})
		end
	end
	APmodule.AppAddBodygroup = AppAddBodygroup
end
OverwriteRegistration()

-- Improved Robust Validator
local function OverwriteValidator()
	APmodule.ValidateFunctions.AModel = function(str)
		if not isstring(str) then return false end
		if not APmodule.PlayerModels or not APmodule.PlayerModels[1] or table.IsEmpty(APmodule.PlayerModels[1]) then return true end
		if not APmodule.PlayerModels[1][str] and not APmodule.PlayerModels[2][str] then return false end
		return true
	end

	APmodule.ValidateFunctions.AClothes = function(tbl) return istable(tbl) end
	APmodule.ValidateFunctions.AName = function(str) return isstring(str) end
	APmodule.ValidateFunctions.AColor = function(clr) return istable(clr) end
	APmodule.ValidateFunctions.AAttachments = function(tbl) return istable(tbl) end
	APmodule.ValidateFunctions.ABodygroups = function(tbl) return istable(tbl) end
	APmodule.ValidateFunctions.AFacemap = function(str) return isstring(str) end

	APmodule.AppearanceValidater = function(tblAppearance)
		if not istable(tblAppearance) then return false end
		local ValidFuncs = APmodule.ValidateFunctions
		
		local function check(key, val)
			if ValidFuncs[key] then 
				local success, result = pcall(ValidFuncs[key], val)
				if success then return result end
			end
			return true
		end

		if not check("AModel", tblAppearance.AModel) then return false end
		if not check("AClothes", tblAppearance.AClothes) then return false end
		if not check("AName", tblAppearance.AName) then return false end
		
		return true
	end
end
OverwriteValidator()

if SERVER then
	util.AddNetworkString("Get_Appearance")
	util.AddNetworkString("OnlyGet_Appearance")

	-- Basic name generator fallback
	APmodule.RandomNames = APmodule.RandomNames or {
		[1] = {"John Doe", "James Smith", "Robert Miller", "Michael Brown"},
		[2] = {"Jane Doe", "Mary Smith", "Patricia Miller", "Linda Brown"}
	}

	function APmodule.GenerateRandomName(iSex)
		local sex = iSex or math.random(1, 2)
		local names = APmodule.RandomNames[sex]
		return names[math.random(1, #names)]
	end

	-- Safe CheckAttachments
	local function CheckAttachments(ply, tbl)
		if not IsValid(ply) or not ply:IsPlayer() or not tbl then return tbl end
		if APmodule.GetAccessToAll and APmodule.GetAccessToAll(ply) then return tbl end
		
		local PSmodule = hg.PointShop
		if tbl.AAttachments then
			for i = 1, #tbl.AAttachments do
				local uid = tbl.AAttachments[i]
				if not uid or uid == "" or uid == "none" then continue end
				if PSmodule and PSmodule.Items and PSmodule.Items[uid] and ply.PS_HasItem and not ply:PS_HasItem(uid) then
					tbl.AAttachments[i] = ""
				end
				if hg.Accessories and hg.Accessories[uid] and hg.Accessories[uid].disallowinappearance then
					tbl.AAttachments[i] = ""
				end
			end
		end

		local tMdl = APmodule.PlayerModels and APmodule.PlayerModels[1] and (APmodule.PlayerModels[1][tbl.AModel] or APmodule.PlayerModels[2][tbl.AModel]) or tbl.AModel
		tbl.ABodygroups = tbl.ABodygroups or {}
		
		for k, v in pairs(tbl.ABodygroups) do
			if not APmodule.Bodygroups or not APmodule.Bodygroups[k] then continue end
			local sexIdx = (istable(tMdl) and tMdl.sex) and 2 or 1
			if not APmodule.Bodygroups[k][sexIdx] then continue end
			
			local bodygroup = APmodule.Bodygroups[k][sexIdx][v]
			if not bodygroup then continue end

			local uid = bodygroup.ID
			if bodygroup[2] and uid and PSmodule and PSmodule.Items and PSmodule.Items[uid] and ply.PS_HasItem and not ply:PS_HasItem(uid) then
				tbl.ABodygroups[k] = nil
			end
		end

		return tbl
	end
	APmodule.CheckAttachments = CheckAttachments

	-- Safe ForceApplyAppearance
	local function ForceApplyAppearance(ply, tbl, noModelChange)
		if not IsValid(ply) or not tbl then return end
		
		local tMdl = APmodule.PlayerModels and APmodule.PlayerModels[1] and (APmodule.PlayerModels[1][tbl.AModel] or APmodule.PlayerModels[2][tbl.AModel]) or tbl.AModel
		local mdl = istable(tMdl) and tMdl.mdl or tMdl
		
		if mdl and mdl ~= "" and mdl ~= ply:GetModel() and not noModelChange then
			ply:SetModel(mdl)
		end

		local clr = tbl.AColor
		if istable(clr) and clr.r and clr.g and clr.b then
			if ply.SetPlayerColor then
				ply:SetPlayerColor(Vector(clr.r / 255, clr.g / 255, clr.b / 255))
			end
			ply:SetNWVector("PlayerColor", Vector(clr.r / 255, clr.g / 255, clr.b / 255))
		end

		ply:SetSubMaterial()

		local mats = ply:GetMaterials()
		if istable(tMdl) and tMdl.submatSlots then
			for k, v in pairs(tMdl.submatSlots) do
				local slot = -1
				for i = 1, #mats do
					if mats[i] == v then slot = i - 1 break end
				end
				
				if slot ~= -1 then
					local sexIdx = tMdl.sex and 2 or 1
					local clothName = (tbl.AClothes and tbl.AClothes[k]) or "normal"
					local clothesTable = APmodule.Clothes[sexIdx]
					local mat = clothesTable and (clothesTable[clothName] or clothesTable["normal"])
					
					if mat then
						ply:SetSubMaterial(slot, mat)
					end
					ply:SetNWString("Colthes" .. k, clothName)
				end
			end
		end
		
		if tbl.AFacemap then
			for i = 1, #mats do
				local facemap = tbl.AFacemap or "Default"
				if APmodule.FacemapsSlots[mats[i]] and APmodule.FacemapsSlots[mats[i]][facemap] then
					ply:SetSubMaterial(i - 1, APmodule.FacemapsSlots[mats[i]][facemap])
				end
			end
		end

		if tbl.AName then
			ply:SetNWString("PlayerName", tbl.AName)
		end
		
		if ply.SetBodyGroups then
			ply:SetBodyGroups("00000000000000000000")
		end

		local bodygroups = ply:GetBodyGroups()
		tbl.ABodygroups = tbl.ABodygroups or {}
		for k, v in ipairs(bodygroups) do
			local groupName = v.name
			if not groupName then continue end
			local chosenGroup = tbl.ABodygroups[groupName]
			if not chosenGroup then continue end
			
			local bgTable = APmodule.Bodygroups[groupName]
			if not bgTable then continue end
			
			local sexIdx = (istable(tMdl) and tMdl.sex) and 2 or 1
			local sexTable = bgTable[sexIdx]
			if not sexTable then continue end
			
			local bodygroupData = sexTable[chosenGroup]
			if not bodygroupData then continue end

			for i = 0, #v.submodels do
				if bodygroupData[1] == v.submodels[i] then
					ply:SetBodygroup(k - 1, i)
					break
				end
			end
		end

		ply:SetNetVar("Accessories", tbl.AAttachments or {})
		ply.CurAppearance = table.Copy(tbl)
	end
	APmodule.ForceApplyAppearance = ForceApplyAppearance

	-- Safe WearAppearance
	local function WearAppearance(ply, tbl)
		if not IsValid(ply) or not tbl then return end
		local checked = CheckAttachments(ply, tbl)
		ForceApplyAppearance(ply, checked)
	end

	-- GetRandomAppearance Implementation
	function APmodule.GetRandomAppearance()
		local iSex = math.random(1, 2)
		local models = APmodule.PlayerModels and APmodule.PlayerModels[iSex]
		local modelName, modelData
		
		if models and not table.IsEmpty(models) then
			modelName, modelData = table.Random(models)
		end
		
		if not modelName then
			modelName = iSex == 1 and "Male 01" or "Female 01"
			modelData = { mdl = iSex == 1 and "models/player/group01/male_01.mdl" or "models/player/group01/female_01.mdl" }
		end

		local clothes = APmodule.Clothes and APmodule.Clothes[iSex]
		local clothName = (clothes and not table.IsEmpty(clothes)) and table.Random(clothes) or "normal"

		return {
			AModel = modelName,
			AClothes = {
				main = clothName,
				pants = clothName,
				boots = clothName
			},
			AName = (APmodule.GenerateRandomName and APmodule.GenerateRandomName(iSex)) or "John Doe",
			AColor = Color(math.random(0, 255), math.random(0, 255), math.random(0, 255)),
			AAttachments = {},
			ABodygroups = {},
			AFacemap = "Default"
		}
	end

	local tWaitResponse = {}

	-- Global ApplyAppearance Override
	function ApplyAppearance(Client, tAppearance, bRandom, bResponeIsValid, bUseCahsed)
		if not IsValid(Client) then return end
		
		if bRandom or (Client.IsBot and Client:IsBot()) or (Client.IsRagdoll and Client:IsRagdoll()) then
			tAppearance = APmodule.GetRandomAppearance()
			WearAppearance(Client, tAppearance)
			return
		end

		if bUseCahsed then
			tAppearance = Client.CachedAppearance or APmodule.GetRandomAppearance()
			if not APmodule.AppearanceValidater(tAppearance) then 
				tAppearance = APmodule.GetRandomAppearance() 
			end
			
			net.Start("OnlyGet_Appearance")
			net.Send(Client)
			
			WearAppearance(Client, tAppearance)
			return
		end

		if not bResponeIsValid then
			tWaitResponse[Client] = CurTime() + 3
			net.Start("Get_Appearance")
			net.Send(Client)
			return
		end

		if not tWaitResponse[Client] or tWaitResponse[Client] < CurTime() then
			ApplyAppearance(Client, nil, true)
			return
		end

		if not tAppearance or not APmodule.AppearanceValidater(tAppearance) then
			ApplyAppearance(Client, nil, true)
			return
		end

		WearAppearance(Client, tAppearance)
	end
	APmodule.ApplyAppearance = ApplyAppearance

	net.Receive("Get_Appearance", function(len, client)
		if not IsValid(client) then return end
		local tAppearance = net.ReadTable()
		local bRandom = net.ReadBool()
		
		if not APmodule.AppearanceValidater(tAppearance) then bRandom = true end
		
		ApplyAppearance(client, tAppearance, (not tAppearance or table.IsEmpty(tAppearance)) and true or bRandom, true)
	end)

	net.Receive("OnlyGet_Appearance", function(len, client)
		if not IsValid(client) then return end
		local tAppearance = net.ReadTable()
		local bRandom = not tAppearance or table.IsEmpty(tAppearance)
		client.CachedAppearance = bRandom and APmodule.GetRandomAppearance() or tAppearance
	end)

	-- Ragdoll apply
	function ApplyAppearanceRagdoll(ent, ply)
		if not IsValid(ent) or not IsValid(ply) then return end
		local Appearance = ply.CurAppearance
		if not Appearance then return end
		
		ent:SetNWString("PlayerName", ply:GetNWString("PlayerName", Appearance.AName))
		ent:SetNetVar("Accessories", ply:GetNetVar("Accessories", {}))

		local tMdl = APmodule.PlayerModels and APmodule.PlayerModels[1] and (APmodule.PlayerModels[1][ent:GetModel()] or APmodule.PlayerModels[2][ent:GetModel()]) or ent:GetModel()
		if istable(tMdl) then
			local mats = ent:GetMaterials()
			if tMdl.submatSlots then
				for k, v in pairs(tMdl.submatSlots) do
					local clothName = ply:GetNWString("Colthes" .. k, "normal")
					ent:SetNWString("Colthes" .. k, clothName)
					
					local slot = -1
					for i = 1, #mats do
						if mats[i] == v then slot = i - 1 break end
					end
					
					if slot ~= -1 then
						local sexIdx = tMdl.sex and 2 or 1
						local clothesTable = APmodule.Clothes[sexIdx]
						local mat = clothesTable and (clothesTable[clothName] or clothesTable["normal"])
						if mat then
							ent:SetSubMaterial(slot, mat)
						end
					end
				end
			end
			
			local facemap = Appearance.AFacemap or "Default"
			for i = 1, #mats do
				if APmodule.FacemapsSlots[mats[i]] and APmodule.FacemapsSlots[mats[i]][facemap] then
					ent:SetSubMaterial(i - 1, APmodule.FacemapsSlots[mats[i]][facemap])
				end
			end
		end
	end
end

-- AUTOMATIC ADDON LOADER
local function LoadCustomAppearances()
	print("[Z-City Appearance Fix] Loading custom appearance content...")
	local files, _ = file.Find("homigrad/new_appearance/custom/*.lua", "LUA")
	for _, filename in ipairs(files) do
		local path = "homigrad/new_appearance/custom/" .. filename
		include(path)
		if SERVER then AddCSLuaFile(path) end
		print("[Z-City Appearance Fix] Auto-loaded custom appearance file: " .. filename)
	end
end

-- FORCED RE-INITIALIZATION HOOKS (Ensures fix sticks on Dedicated Server)
local function PerformAllFixes()
	print("[Z-City Appearance Fix] Performing forced system override...")
	SetupTables()
	OverwriteRegistration()
	OverwriteValidator()
	LoadCustomAppearances()
end

-- Hook into everything possible to ensure we win the loading race
hook.Add("Initialize", "ZCityAppearanceFix_Initialize", PerformAllFixes)
hook.Add("InitPostEntity", "ZCityAppearanceFix_PostEntity", PerformAllFixes)
hook.Add("PostGamemodeLoaded", "ZCityAppearanceFix_PostGM", PerformAllFixes)

-- Run once immediately for hot-reload/P2P
PerformAllFixes()

-- Final safety timer for Dedicated Servers
if SERVER then
	timer.Simple(5, function()
		print("[Z-City Appearance Fix] Final check for system stability...")
		PerformAllFixes()
	end)
end
