if SERVER then AddCSLuaFile() end
SWEP.Base = "weapon_rem_melee_base"
-- Автогенерация: build/gen_melee.py — из weapon_hg_sledgehammer.lua архива Remorseim
SWEP.PrintName = "Sledgehammer (Rem)"
SWEP.Instructions = "The Sledgehammer is a two-handed tool which can be used as a melee weapon.\n\nLMB to attack.\nRMB to block."
SWEP.Category = "Weapons - Remorseim Melee"
SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.Weight = 0

SWEP.WorldModel = "models/weapons/tfa_nmrih/w_me_sledge.mdl"
SWEP.WorldModelReal = "models/weapons/tfa_nmrih/v_me_sledge.mdl"
SWEP.WorldModelExchange = "models/weapons/ravaged/w_ravaged_sledgehammer.mdl"
SWEP.ViewModel = ""

SWEP.HoldType = "revolver"

SWEP.weight = 3.5

SWEP.HoldPos = Vector(-14,-2,1)
SWEP.HoldAng = Angle(0,0,0)

SWEP.AttackTime = 0.49
SWEP.AnimTime1 = 2.1
SWEP.WaitTime1 = 2
SWEP.ViewPunch1 = Angle(1,2,0)

SWEP.Attack2Time = 0.3
SWEP.AnimTime2 = 1
SWEP.WaitTime2 = 0.8
SWEP.ViewPunch2 = Angle(0,0,-2)

SWEP.attack_ang = Angle(0,0,-15)
SWEP.sprint_ang = Angle(15,0,0)

SWEP.basebone = 94

SWEP.weaponPos = Vector(0,0,0)
SWEP.weaponAng = Angle(0,-90,0)

SWEP.DamagePrimary = 67
SWEP.DamageSecondary = 34
SWEP.HitCooldownEnabled = true
SWEP.HitCooldown = 2.5
SWEP.ComboEnabled = true
SWEP.ComboResetTime = 3
SWEP.ComboDamageMul1 = 1
SWEP.ComboDamageMul2 = 1.25
SWEP.ComboDamageMul3 = 1.65

SWEP.PenetrationPrimary = 5
SWEP.PenetrationSecondary = 7

SWEP.MaxPenLen = 6

SWEP.PenetrationSizePrimary = 4
SWEP.PenetrationSizeSecondary = 1.25

SWEP.StaminaPrimary = 43
SWEP.StaminaSecondary = 35

SWEP.canchargeattack = true
SWEP.ChargeAnimTimeBegin = 1.45
SWEP.ChargeAnimTimeIdle = 1
SWEP.ChargeAnimTimeEnd = 1.65
SWEP.ChargeFullTime = 0.65
SWEP.ChargeAttackTime = 0.29
SWEP.ChargeWaitTime = 2.5
SWEP.ChargeAttackLen = 70
SWEP.ChargeAttackTimeLength = 0.28
SWEP.ChargeAttackRads = 85
SWEP.ChargeSwingAng = -105
SWEP.BlockDirectionalPrimary = "left"
SWEP.BlockDirectionalCharge = "overhead"
SWEP.ChargeStamina = 75
SWEP.ChargePenetration = 8
SWEP.ChargePenetrationSize = 6.5
SWEP.ChargeDamageMul = 1.85
SWEP.ChargeBreakBoneMul = 1.85
SWEP.ChargeTapCancelTime = 1
SWEP.ChargeViewPunch = Angle(12, 0, 0)
SWEP.ChargeHoldPos = Vector(-10,-2,1)


SWEP.AttackLen1 = 65
SWEP.AttackLen2 = 45

SWEP.AnimList = {
    ["idle"] = "Idle",
    ["deploy"] = "Draw",
    ["attack"] = "Attack_Quick",
    ["attack2"] = "Shove",
}

if CLIENT then
	SWEP.WepSelectIcon = Material("vgui/hud/ravaged_sledgehammer")
	SWEP.IconOverride = "vgui/hud/ravaged_sledgehammer"
	SWEP.BounceWeaponIcon = false
end

SWEP.setlh = true
SWEP.setrh = true
SWEP.TwoHanded = true

SWEP.AttackHit = "Canister.ImpactHard"
SWEP.Attack2Hit = "Canister.ImpactHard"
SWEP.AttackHitFlesh = "Flesh.ImpactHard"
SWEP.Attack2HitFlesh = "Flesh.ImpactHard"
SWEP.DeploySnd = "physics/wood/wood_plank_impact_soft2.wav"

SWEP.swingsoundextra = {
    {"bat/baseball_swing_1st_layer_01.wav", 60, {80, 90}},
    {"bat/baseball_swing_1st_layer_02.wav", 60, {80, 90}},
    {"bat/baseball_swing_1st_layer_03.wav", 60, {80, 90}},
    {"bat/baseball_swing_1st_layer_04.wav", 60, {80, 90}},
}

SWEP.hitsoundextra = {
    {"sledgehammer/rem_maul1.wav", 70, {72, 82}},
    {"sledgehammer/rem_maul2.wav", 70, {72, 82}},
    {"sledgehammer/rem_maul3.wav", 70, {72, 82}},
    {"sledgehammer/rem_maul4.wav", 70, {72, 82}},
}

SWEP.hitsoundbrutalize = {
    {"hammerbrutalize/rem_hammerbrutalize1.wav", 70, {90, 100}},
    {"hammerbrutalize/rem_hammerbrutalize2.wav", 70, {90, 100}},
    {"hammerbrutalize/rem_hammerbrutalize3.wav", 70, {90, 100}},
    {"hammerbrutalize/rem_hammerbrutalize4.wav", 70, {90, 100}},
}

SWEP.AttackPos = Vector(0,0,0)
SWEP.BlockTier = 5
SWEP.BlockMaterial = "metal"
SWEP.BlockSound = {"physics/metal/metal_solid_impact_hard1.wav", 68, {95, 102}}

function SWEP:CanSecondaryAttack()
    self.DamageType = DMG_CLUB
    self.AttackHit = "Canister.ImpactHard"
    self.Attack2Hit = "Canister.ImpactHard"
    return true
end

function SWEP:CanPrimaryAttack()
    self.DamageType = DMG_CLUB
    self.AttackHit = "Concrete.ImpactHard"
    self.Attack2Hit = "Concrete.ImpactHard"
    return true
end

function SWEP:PrimaryAttackAdd(ent)
    if hgIsDoor(ent) and math.random(7) > 3 then
        hgBlastThatDoor(ent,self:GetOwner():GetAimVector() * 50 + self:GetOwner():GetVelocity())
    end
end

function SWEP:CustomBlockAnim(addPosLerp, addAngLerp)
    addPosLerp.z = addPosLerp.z + (self:GetBlocking() and -2 or 0)
    addPosLerp.x = addPosLerp.x + (self:GetBlocking() and 2 or 0)
    addPosLerp.y = addPosLerp.y + (self:GetBlocking() and -5 or 0)
    addAngLerp.p = addAngLerp.p + (self:GetBlocking() and 15 or 0)
    addAngLerp.r = addAngLerp.r + (self:GetBlocking() and 45 or 0)

    return true
end

SWEP.NoHolster = true

SWEP.AttackTimeLength = 0.28
SWEP.Attack2TimeLength = 0.01

SWEP.AttackRads = 95
SWEP.AttackRads2 = 0

SWEP.SwingAng = -165
SWEP.SwingAng2 = 0

SWEP.MinSensivity = 0.87
