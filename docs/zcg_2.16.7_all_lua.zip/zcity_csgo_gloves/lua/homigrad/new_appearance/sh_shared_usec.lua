hg.Appearance.Clothes[1]["usec"] = "models/humans/male/group01/usec"

--i used bib's custom shirts as a base. i just changed name of the clothes and thats it, all credits goes to the bib--