--[[

    Короче говоря это тест кода от дипсика, ввиду того что я не особо хорош в кодинге и аспектах луа в гаррисе, я решил подтянуть его для этой задачи
    и сделать файл максимально совместимым со всеми возможными аддонами на зсити
    буду тестить и решать возникающие проблемы на ходу. всем кто читает большой привет, поразбираетесь со мной.

]]

-- Дополнение для ZCity Appearance

-- Убеждаемся, что глобальные таблицы существуют (на случай, если файл загрузится до оригинала)
hg.Appearance = hg.Appearance or {}
hg.PointShop = hg.PointShop or {}
-- НЕ переопределяем PLUGIN.Items
--[[
hg.Appearance.MenuPerf = hg.Appearance.MenuPerf or {
    showcaseCols = 12,
    allFacemapsCols = 14,
    allFacemapsHeaderGapFactor = 0.43,
    clothesCols = 4,
    facemapCols = 3,
    glovesCols = 3,
    modelCols = 4
}
]]
-- === ВАЖНО: Инициализация таблицы для хранения слотов лица ===
hg.Appearance.ModelFaceSlots = hg.Appearance.ModelFaceSlots or {}
-- ============================================================


hg.Appearance.PlayerModels = hg.Appearance.PlayerModels or { [1] = {}, [2] = {} }
hg.Appearance.Clothes = hg.Appearance.Clothes or { [1] = {}, [2] = {} }
hg.Appearance.ClothesDesc = hg.Appearance.ClothesDesc or {}
hg.Appearance.FacemapsSlots = hg.Appearance.FacemapsSlots or {}
hg.Appearance.FacemapsModels = hg.Appearance.FacemapsModels or {}

-- Добавление новой одежды
local function AddCustomColorableClothes()
    hg.Appearance.Clothes = hg.Appearance.Clothes or { [1] = {}, [2] = {} }
    hg.Appearance.ClothesDesc = hg.Appearance.ClothesDesc or {}

    -- Новая мужская одежда
    local maleClothes = {
        Tshirt_cl = "models/gate/shirt",
        Gate_Shirt2 = "models/gate/shirt2",
		Gate_Shirt = "models/gate/Sweatshirt", 
        Applewhite_sweatshirt = "models/gate/Epl",
        Napapijri_jacket = "models/gate/Napapijri_jacket",
        Napapijri_jacket_black = "models/gate/Napapijri_jacket_black",
        Applewhite_sweater = "models/gate/sweater",
        woody_sweater = "models/gate/woody_sweater",
        skull = "models/gate/skull",
    }
    for id, path in pairs(maleClothes) do
        hg.Appearance.Clothes[1][id] = path
        hg.Appearance.ClothesDesc[id] = hg.Appearance.ClothesDesc[id] or { desc = "Unique clothes from Colorable Clothes! How original..." }
    end

    -- Новая женская одежда
    local femaleClothes = {
    }
    for id, path in pairs(femaleClothes) do
        hg.Appearance.Clothes[2][id] = path
        hg.Appearance.ClothesDesc[id] = hg.Appearance.ClothesDesc[id] or { desc = "Unique clothes from Colorable Clothes! How unoriginal..." }
    end

end



-- Вызов всех функций добавления
-- Лучше всего вызывать их в хуке, чтобы быть уверенным, что основные таблицы уже созданы.
hook.Add("Initialize", "CustomColorableAppearance_Init", function()
    AddCustomColorableClothes()
end)

hook.Add("InitPostEntity", "ZCity_LoadCustomColorableAppearance", function()
    AddCustomColorableClothes()
end)

hook.Add("OnGamemodeLoaded", "ZCity_LoadCustomColorableAppearance", function()
    AddCustomColorableClothes()
end)

hook.Add("PostGamemodeLoaded", "ZCity_LoadCustomColorableAppearance_PostGM", function()
    AddCustomColorableClothes()
end)

if SERVER then
    local function PatchAppearanceReset()
        local appearanceTable = hg.Appearance
        if not appearanceTable or appearanceTable.__ZCitySubmaterialResetPatched then return end
        local originalForceApply = appearanceTable.ForceApplyAppearance
        if not isfunction(originalForceApply) then return end

        appearanceTable.__ZCitySubmaterialResetPatched = true
        appearanceTable.ForceApplyAppearance = function(ply, tbl, noModelChange)
            if IsValid(ply) and ply.GetMaterials and ply.SetSubMaterial then
                local mats = ply:GetMaterials() or {}
                for i = 1, #mats do
                    ply:SetSubMaterial(i - 1, nil)
                end
            end

            return originalForceApply(ply, tbl, noModelChange)
        end
    end

    hook.Add("InitPostEntity", "ZCity_PatchForceApplyAppearanceReset", function()
        PatchAppearanceReset()
        timer.Create("ZCity_PatchForceApplyAppearanceResetRetry", 0.5, 20, function()
            if hg.Appearance and hg.Appearance.__ZCitySubmaterialResetPatched then
                timer.Remove("ZCity_PatchForceApplyAppearanceResetRetry")
                return
            end
            PatchAppearanceReset()
        end)
    end)
end