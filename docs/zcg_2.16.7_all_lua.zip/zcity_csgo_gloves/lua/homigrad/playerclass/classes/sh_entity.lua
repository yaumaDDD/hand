local CLASS = player.RegClass("entity")

function CLASS.Off(self)
    if CLIENT then return end
end

local models = {
    "models/player/zombie_fast.mdl",
	"models/player/corpse1.mdl",
	"models/player/charple.mdl",
}

function CLASS.On(self)
    if CLIENT then return end
    ApplyAppearance(self,nil,nil,nil,true)
    self:SetPlayerColor(Color(10,10,100):ToVector())
    self:SetModel(models[math.random(#models)])
    self:SetSubMaterial()
    timer.Simple(0,function()
        self:SetBodyGroups("00000000000")
    end)
    local Appearance = self.CurAppearance or hg.Appearance.GetRandomAppearance()
    Appearance.AAttachments = ""
    Appearance.AColthes = ""
    self:SetNetVar("Accessories", "")
    self.CurAppearance = Appearance
    local inv = self:GetNetVar("Inventory", {})
    inv["Weapons"] = inv["Weapons"] or {}
    inv["Weapons"]["hg_sling"] = true
    self:SetNetVar("Inventory", inv)

    self:SetNWString("PlayerName","The Entity")
end

--// Phrase stuff
local zomb_pain = {"npc/zombie/zombie_die2.wav"}
for i = 1, 6 do
	table.insert(zomb_pain, "npc/zombie/zombie_pain" .. i .. ".wav")
end

local zomb_phrases, zomb_burnphrases = {}, {}
for i = 1, 3 do
	table.insert(zomb_phrases, "npc/zombie/zombie_alert" .. i .. ".wav")
end
for i = 1, 14 do
	table.insert(zomb_phrases, "npc/zombie/zombie_voice_idle" .. i .. ".wav")
	table.insert(zomb_burnphrases, "npc/zombie/zombie_voice_idle" .. i .. ".wav")
end

hook.Add("HG_ReplaceBurnPhrase", "ZombBurnPhrases", function(ply, phrase)
	if ply.PlayerClassName == "headcrabzombie" then
		return ply, zomb_burnphrases[math.random(#zomb_burnphrases)]
	end
end)

hook.Add("HG_ReplacePhrase", "ZombPhrases", function(ply, phrase, muffed, pitch) -- pitch means pitched effect, not exact sound pitch
	if ply.PlayerClassName == "headcrabzombie" then
		local inpain = ply.organism.pain > 30
		local phr = (inpain and zomb_pain[math.random(#zomb_pain)] or zomb_phrases[math.random(#zomb_phrases)])

		return ply, phr, inpain and false or true, pitch -- pitch effect will be useful for zombine
	end
end)

function CLASS.Guilt(self, Victim)
    if CLIENT then return end

    if Victim:GetPlayerClass() == self:GetPlayerClass() then
        return 1
    end

    if Victim == zb.hostage then
        return 1
    end

    return 1
end

hook.Add("HG_PlayerFootstep", "ZombSteps", function(ply)
		local chr = hg.GetCurrentCharacter(ply)
		if ply:Alive() and ply.PlayerClassName == "entity" then
			if IsValid(ply.FakeRagdoll) and ply:GetNetVar("lastFake") == 0 then return end
			if not ply:IsSprinting() and (ply:KeyDown(IN_DUCK) or ply:KeyDown(IN_WALK)) then
				chr:EmitSound("npc/zombie/foot_slide" .. math.random(3) .. ".wav", 60, math.random(95, 105), 0.5)
			else
				chr:EmitSound("npc/zombie/foot" .. math.random(3) .. ".wav", 65, math.random(95, 105))
			end
			return true
		end
	end)