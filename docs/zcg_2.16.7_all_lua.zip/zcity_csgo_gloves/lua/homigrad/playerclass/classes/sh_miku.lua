local CLASS = player.RegClass("vocaloid")

function CLASS.Off(self)
    if CLIENT then return end
end

function CLASS.On(self)
    if CLIENT then return end
    local Appearance = self.CurAppearance

	self:SetPlayerColor(Color(31, 209, 200):ToVector())
	self:SetModel("models/player/dewobedil/vocaloid/appearance_miku/default_p.mdl")
	self:SetSubMaterial()
    Appearance.AAttachments = ""
    Appearance.AColthes = ""
    self:SetNetVar("Accessories", "")
	self:SetBodygroup(1,0)
	self:SetBodygroup(2,0) 
	self:SetBodygroup(3,0)
	self:SetBodygroup(4,0)
	self:SetBodygroup(5,0)
	
	self.CurAppearance = Appearance
	self:SetNWString("PlayerName","Hatsune Miku")
end

CLASS.CanUseDefaultPhrase = true
CLASS.CanEmitRNDSound = false
CLASS.CanUseGestures = true

function CLASS.Guilt(self, Victim)
    if CLIENT then return end
end