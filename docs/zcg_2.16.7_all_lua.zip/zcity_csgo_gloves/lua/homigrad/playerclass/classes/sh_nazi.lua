local CLASS = player.RegClass("Nazi German")

function CLASS.Off(self)
    if CLIENT then return end
end

local models = {
 "models/player/dod_german.mdl",
}

local ranks = {
    {name = "SS-Oberführer", chance = 5},
    {name = "SS-Standartenführer", chance = 5},
    {name = "SS-Obersturmbannführer", chance = 15},
    {name = "SS-Oberschütze", chance = 35},
    {name = "SS-Schütze", chance = 45},
    {name = "SS-Obergefreiter", chance = 80}
}

local clr = Color(10, 10, 100):ToVector()
function CLASS.On(self)
    if CLIENT then return end
    ApplyAppearance(self,nil,nil,nil,true)
    local Appearance = self.CurAppearance
    Appearance.AAttachments = ""
    Appearance.AColthes = ""

    local randomValue = math.random(100)
    local cumulativeChance = 0
    local rank = "SS-Obergefreiter"

    for _, rankInfo in ipairs(ranks) do
        cumulativeChance = cumulativeChance + rankInfo.chance
        if randomValue <= cumulativeChance then
            rank = rankInfo.name
            break
        end
    end

    self:SetNWString("PlayerName", rank .. " " .. Appearance.AName)
    self:SetPlayerColor(clr)
    self:SetModel(models[string.lower(Appearance.AModel)] or table.Random(models))
    for _, bg in ipairs(self:GetBodyGroups()) do
		self:SetBodygroup(0, math.random(0, 1)) 
		self:SetBodygroup(1, math.random(0, bg.num))
	end
    self:SetNetVar("Accessories", Appearance.AAttachmets or "none")
    self.CurAppearance = Appearance
	  local inv = self:GetNetVar("Inventory", {})
    inv["Weapons"] = inv["Weapons"] or {}
    inv["Weapons"]["hg_sling"] = true
    self:SetNetVar("Inventory", inv)
end

function CLASS.Guilt(self, Victim)
    if CLIENT then return end

    if Victim:GetPlayerClass() == self:GetPlayerClass() then
        --self:ChatPrint("You killed your teammate!")
        return 1
    end 
	
	hook.Add("HG_PlayerFootstep", "nazi_footsteps", function(ply, pos, foot, sound, volume, rf)
	local chr = hg.GetCurrentCharacter(ply)
	if ply:Alive() and ply.PlayerClassName == "nazi" then
		local ent = hg.GetCurrentCharacter(ply)

		if not (ply:IsWalking() or ply:Crouching()) and ent == ply then
			local snd = "zcitysnd/" .. string.Replace(sound, "player/footsteps", "player/footsteps_military/")
			if SoundDuration(snd) <= 0 then
				snd = sound -- missing footsteps fix
			end

			EmitSound(snd, pos, ply:EntIndex(), CHAN_AUTO, volume, 75, nil, changePitch(math.random(95,105)) )

			return true
			end
			end 
			end)
			
    return 1
end

