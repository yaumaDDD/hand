-- ZCity Drill Clothes
-- Registers the original streetwear textures from the supplied Part 1 + Part 2 packs
-- in the existing hg.Appearance.Clothes menu.

local entries = {
    {"Drill 01", "zcity_drill/players_sheet_02"},
    {"Drill 02", "zcity_drill/players_sheet_04"},
    {"Drill 03", "zcity_drill/players_sheet_06"},
    {"Drill 04", "zcity_drill/players_sheet_07"},
    {"Drill 05", "zcity_drill/players_sheet_09"},
    {"Drill 06", "zcity_drill/sheet_01"},
    {"Drill 07", "zcity_drill/sheet_16"},
    {"Drill 08", "zcity_drill/sheet_31"},
    {"Drill 09", "zcity_drill/sheet_32"},
    {"Drill 10", "zcity_drill/sheet_33"},
    {"Drill 11", "zcity_drill/sheet_34"},
    {"Drill 12", "zcity_drill/sheet_35"},
    {"Drill 13", "zcity_drill/sheet_36"},
    {"Drill 14", "zcity_drill/sheet_37"},
    {"Drill 15", "zcity_drill/sheet_38"},
    {"Drill 16", "zcity_drill/sheet_39"},
    {"Drill 17", "zcity_drill/sheet_40"},
    {"Drill 18", "zcity_drill/sheet_41"},
    {"Drill 19", "zcity_drill/sheet_42"},
    {"Drill 20", "zcity_drill/sheet_43"},
    {"Drill 21", "zcity_drill/sheet_44"},
    {"Drill 22", "zcity_drill/sheet_45"},
}

local function Register()
    if not hg or not hg.Appearance or not hg.Appearance.Clothes then return false end
    hg.Appearance.Clothes[1] = hg.Appearance.Clothes[1] or {}
    hg.Appearance.Clothes[2] = hg.Appearance.Clothes[2] or {}
    hg.Appearance.ClothesDesc = hg.Appearance.ClothesDesc or {}

    for _, item in ipairs(entries) do
        local name, material = item[1], item[2]
        -- Same registration is available to the Jacket/Pants/Boots selectors.
        hg.Appearance.Clothes[1][name] = material
        hg.Appearance.Clothes[2][name] = material
        hg.Appearance.ClothesDesc[name] = {
            desc = "Drill / Streetwear — imported from supplied Part 1 + Part 2 pack"
        }
    end
    return true
end

if SERVER then
    AddCSLuaFile()
end

-- Gamemode appearance is loaded by the gamemode loader. Register after it exists.
hook.Add("InitPostEntity", "ZCityDrillClothes_Register", function()
    if Register() then return end
    timer.Create("ZCityDrillClothes_Wait", 0.25, 40, function()
        if Register() then timer.Remove("ZCityDrillClothes_Wait") end
    end)
end)

-- Also try immediately for reloads where Appearance is already initialized.
Register()
