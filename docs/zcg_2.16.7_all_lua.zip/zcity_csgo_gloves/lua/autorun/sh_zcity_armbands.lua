-- Z-City Armbands
-- Adds colored armbands (left upper arm) as wearable accessories for the Z-City appearance system.
-- Uses a recolorable (grayscale) version of Z-City's own team armband model,
-- so the band wraps the arm correctly via bonemerge.
-- Armbands appear in the appearance editor under the "Body" menu.

local COLORS = {
	{id = "red",    name = "Red",    color = Vector(1, 0.08, 0.08)},
	{id = "blue",   name = "Blue",   color = Vector(0.15, 0.3, 1)},
	{id = "green",  name = "Green",  color = Vector(0.15, 0.85, 0.2)},
	{id = "yellow", name = "Yellow", color = Vector(1, 0.85, 0.1)},
	{id = "orange", name = "Orange", color = Vector(1, 0.45, 0.05)},
	{id = "purple", name = "Purple", color = Vector(0.55, 0.2, 0.9)},
	{id = "pink",   name = "Pink",   color = Vector(1, 0.5, 0.75)},
	{id = "cyan",   name = "Cyan",   color = Vector(0.15, 0.85, 0.9)},
	{id = "white",  name = "White",  color = Vector(1, 1, 1)},
	{id = "black",  name = "Black",  color = Vector(0.12, 0.12, 0.12)},
}

local function RegisterArmbands()
	if not istable(hg) or not istable(hg.Accessories) then return end

	for _, data in ipairs(COLORS) do
		hg.Accessories["armband " .. data.id] = {
			model = "models/zcband/band_team.mdl",
			femmodel = "models/zcband/band_team_f.mdl",
			-- same placement values as the original Z-City terrorist_band
			bone = "ValveBiped.Bip01_Head1",
			malepos = {Vector(0.6, -0.95, 0), Angle(180, 100, 90), 0.95},
			fempos = {Vector(-0.6, -0.6, 0), Angle(180, 100, 90), 0.95},
			skin = 0,
			bonemerge = true,
			needcoolRender = true,
			flex = true,
			bSetColor = true,
			vecColorOveride = data.color,
			-- "spine" shows up in the "Body" accessory menu but, unlike "torso",
			-- is not hidden when the player wears body armor
			placement = "spine",
			-- point the editor icon camera at the band mesh (it sits at arm height)
			vpos = Vector(1, 0, 52),
			name = "Armband (" .. data.name .. ")"
		}
	end
end

-- Z-City creates hg.Accessories when it loads, so register after everything is loaded
hook.Add("InitPostEntity", "ZCityArmbands_Register", RegisterArmbands)

-- Also handle lua auto-refresh / late loading
if istable(hg) and istable(hg.Accessories) then
	RegisterArmbands()
end

if SERVER then
	resource.AddFile("models/zcband/band_team.mdl")
	resource.AddFile("models/zcband/band_team_f.mdl")
	resource.AddFile("materials/zcbands41/band_team.vmt")
	resource.AddFile("materials/zcbands41/band_team2.vmt")
	resource.AddFile("materials/zcbands41/band_team2_f.vmt")
	resource.AddFile("materials/zcbands41/band_team_tail.vmt")
end
