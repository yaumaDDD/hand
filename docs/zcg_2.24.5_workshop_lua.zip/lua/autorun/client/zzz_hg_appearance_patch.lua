﻿local PATCH_ID = "HG_AppearanceDedicatedCompatibility"

local function GetAppearanceModule()
    hg = hg or {}
    hg.Appearance = hg.Appearance or {}

    return hg.Appearance
end

local function GetFallbackModelData()
    local appearance = GetAppearanceModule()
    local playerModels = appearance.PlayerModels
    if istable(playerModels) then
        for sexIdx = 1, 2 do
            local sexModels = playerModels[sexIdx]
            if not istable(sexModels) then continue end

            local name, data = next(sexModels)
            if isstring(name) and istable(data) then
                return name, data
            end
        end
    end

    return "Male 01", {
        mdl = "models/player/group01/male_01.mdl",
        sex = false,
        submatSlots = {}
    }
end

local function ResolveModelDataForAppearance(tbl)
    if not istable(tbl) then return nil end

    local appearance = GetAppearanceModule()
    local playerModels = appearance.PlayerModels
    if not istable(playerModels) then return nil end

    local function byName(name)
        if not isstring(name) or name == "" then return nil end
        return (playerModels[1] and playerModels[1][name]) or (playerModels[2] and playerModels[2][name])
    end

    local tMdl = byName(tbl.AModel)
    if tMdl then return tMdl end

    local lply = LocalPlayer()
    if IsValid(lply) then
        local mdlPath = string.lower(lply:GetModel() or "")
        if mdlPath ~= "" then
            for sexIdx = 1, 2 do
                local sexModels = playerModels[sexIdx]
                if not istable(sexModels) then continue end

                for name, data in pairs(sexModels) do
                    if istable(data) and isstring(data.mdl) and string.lower(data.mdl) == mdlPath then
                        tbl.AModel = name
                        return data
                    end
                end
            end
        end
    end

    local skeleton = appearance.SkeletonAppearanceTable
    if istable(skeleton) and isstring(skeleton.AModel) then
        tMdl = byName(skeleton.AModel)
        if tMdl then
            tbl.AModel = skeleton.AModel
            return tMdl
        end
    end

    for sexIdx = 1, 2 do
        local sexModels = playerModels[sexIdx]
        if not istable(sexModels) then continue end

        local name, data = next(sexModels)
        if isstring(name) and istable(data) then
            tbl.AModel = name
            return data
        end
    end

    return nil
end

local function EnsureAppearanceTableDefaults(tbl)
    if not istable(tbl) then return tbl end

    local appearance = GetAppearanceModule()
    local skeleton = appearance.SkeletonAppearanceTable
    if not istable(skeleton) then return tbl end

    if not isstring(tbl.AName) or tbl.AName == "" then
        local lply = LocalPlayer()
        local nwName = IsValid(lply) and lply:GetNWString("PlayerName", "") or ""
        tbl.AName = nwName ~= "" and nwName or ""
    end

    tbl.AColor = tbl.AColor or skeleton.AColor or Color(255, 255, 255)

    if not istable(tbl.AClothes) then
        tbl.AClothes = table.Copy(skeleton.AClothes or {})
    else
        tbl.AClothes.main = tbl.AClothes.main or skeleton.AClothes.main
        tbl.AClothes.pants = tbl.AClothes.pants or tbl.AClothes.main or skeleton.AClothes.main
        tbl.AClothes.boots = tbl.AClothes.boots or tbl.AClothes.main or skeleton.AClothes.main
    end

    if not istable(tbl.AAttachments) then
        tbl.AAttachments = {"none", "none", "none"}
    end

    tbl.ABodygroups = tbl.ABodygroups or {}
    tbl.AFacemap = tbl.AFacemap or skeleton.AFacemap or "Default"

    return tbl
end

local function SanitizeAppearanceTableAgainstCatalog(tbl, modelData)
    if not istable(tbl) then return tbl end

    local appearance = GetAppearanceModule()
    appearance.Clothes = appearance.Clothes or { [1] = {}, [2] = {} }
    appearance.Bodygroups = appearance.Bodygroups or {}
    appearance.FacemapsSlots = appearance.FacemapsSlots or {}

    local sexIndex = (istable(modelData) and modelData.sex) and 2 or 1
    local clothesBySex = appearance.Clothes[sexIndex]
    if not istable(clothesBySex) then
        clothesBySex = {}
        appearance.Clothes[sexIndex] = clothesBySex
    end

    tbl.AClothes = istable(tbl.AClothes) and tbl.AClothes or {}
    for _, part in ipairs({"main", "pants", "boots"}) do
        local selected = tbl.AClothes[part]
        if not isstring(selected) or selected == "" or clothesBySex[selected] == nil then
            tbl.AClothes[part] = clothesBySex.normal and "normal" or next(clothesBySex) or selected or "normal"
        end
    end

    tbl.AAttachments = istable(tbl.AAttachments) and tbl.AAttachments or {}
    for i = 1, 3 do
        if not isstring(tbl.AAttachments[i]) or tbl.AAttachments[i] == "" then
            tbl.AAttachments[i] = "none"
        end
    end

    tbl.ABodygroups = istable(tbl.ABodygroups) and tbl.ABodygroups or {}
    for bodygroupName, selected in pairs(tbl.ABodygroups) do
        local bodygroupCatalog = appearance.Bodygroups[bodygroupName]
        local bodygroupSexCatalog = istable(bodygroupCatalog) and bodygroupCatalog[sexIndex] or nil
        if not isstring(selected) or not istable(bodygroupSexCatalog) or bodygroupSexCatalog[selected] == nil then
            tbl.ABodygroups[bodygroupName] = nil
        end
    end

    if not isstring(tbl.AFacemap) or tbl.AFacemap == "" then
        tbl.AFacemap = "Default"
    end

    return tbl
end

local function NormalizeAppearanceTable(tbl)
    if not istable(tbl) then return tbl end

    EnsureAppearanceTableDefaults(tbl)
    -- a Color does not survive net.WriteTable and JSON alike: a plain table carries the same
    -- numbers and is read back by everything (the server, the file, the preset) (2.24.0)
    if istable(tbl.AColor) and tbl.AColor.r and tbl.AColor.g and tbl.AColor.b then
        tbl.AColor = { r = tbl.AColor.r, g = tbl.AColor.g, b = tbl.AColor.b, a = tbl.AColor.a or 255 }
    end
    local modelData = ResolveModelDataForAppearance(tbl)
    if not modelData then
        local fallbackName, fallbackData = GetFallbackModelData()
        tbl.AModel = fallbackName
        modelData = fallbackData
    end

    SanitizeAppearanceTableAgainstCatalog(tbl, modelData)

    return tbl
end

local function FindFirstChildByClass(parent, className)
    if not IsValid(parent) or not parent.GetChildren then return nil end

    for _, child in ipairs(parent:GetChildren()) do
        if child.GetClassName and child:GetClassName() == className then
            return child
        end

        local nested = FindFirstChildByClass(child, className)
        if IsValid(nested) then
            return nested
        end
    end
end

local function PatchAppearanceViewer(panel)
    if not IsValid(panel) or panel.__DedicatedViewerPatchApplied then return false end

    local viewer = FindFirstChildByClass(panel, "DModelPanel")
    if not IsValid(viewer) then return false end

    panel.__DedicatedViewerPatchApplied = true

    local oldLayoutEntity = viewer.LayoutEntity
    function viewer:LayoutEntity(ent, ...)
        if IsValid(panel) then
            NormalizeAppearanceTable(panel.AppearanceTable)
        end

        local ok, result = xpcall(function()
            if isfunction(oldLayoutEntity) then
                return oldLayoutEntity(self, ent)
            end
        end, debug.traceback)

        if ok then
            return result
        end

        if not IsValid(ent) or not IsValid(panel) then return end

        NormalizeAppearanceTable(panel.AppearanceTable)
        local tbl = panel.AppearanceTable or {}
        local modelData = ResolveModelDataForAppearance(tbl)
        if not modelData then
            local fallbackName, fallbackData = GetFallbackModelData()
            tbl.AModel = fallbackName
            modelData = fallbackData
        end
        if not modelData or not isstring(modelData.mdl) or modelData.mdl == "" then return end

        local drawColor = tbl.AColor or Color(255, 255, 255)
        ent:SetNWVector("PlayerColor", Vector(drawColor.r / 255, drawColor.g / 255, drawColor.b / 255))

        if ent:GetModel() ~= modelData.mdl and util.IsValidModel(tostring(modelData.mdl)) then
            ent:SetModel(modelData.mdl)
            self:SetModel(modelData.mdl)
            tbl.AFacemap = "Default"
        end
    end

    local oldPostDrawModel = viewer.PostDrawModel
    function viewer:PostDrawModel(ent, ...)
        if IsValid(panel) then
            NormalizeAppearanceTable(panel.AppearanceTable)
        end

        local ok, result = xpcall(function()
            if isfunction(oldPostDrawModel) then
                return oldPostDrawModel(self, ent)
            end
        end, debug.traceback)

        if ok then
            return result
        end

        if not IsValid(ent) or not IsValid(panel) then return end

        local tbl = panel.AppearanceTable or {}
        for _, attach in ipairs(tbl.AAttachments or {}) do
            DrawAccesories(ent, ent, attach, hg.Accessories and hg.Accessories[attach], false, true)
        end

        ent:SetupBones()
    end

    return true
end

-- Presets of the appearance editor: the editor this addon ships has a row of its own
-- (cl_appearance_editor1.lua) and marks itself; an editor without one (the plain editor of
-- Z-City) gets the same row from here, so a look that was made can always be kept (2.23.0).
local PRESET_DIR = "zcity/appearances/presets/"

local function PresetSave(name, tbl)
    file.CreateDir(PRESET_DIR)
    file.Write(PRESET_DIR .. name .. ".json", util.TableToJSON(tbl, true))
end

local function PresetLoad(name)
    if not file.Exists(PRESET_DIR .. name .. ".json", "DATA") then return nil end
    return util.JSONToTable(file.Read(PRESET_DIR .. name .. ".json", "DATA"))
end

local function PresetList()
    file.CreateDir(PRESET_DIR)
    local names = {}
    for _, one in ipairs(file.Find(PRESET_DIR .. "*.json", "DATA")) do
        names[#names + 1] = string.StripExtension(one)
    end
    return names
end

local function PresetDelete(name)
    if not file.Exists(PRESET_DIR .. name .. ".json", "DATA") then return false end
    file.Delete(PRESET_DIR .. name .. ".json")
    return true
end

local function PresetPut(panel, tbl)
    panel.AppearanceTable = panel.AppearanceTable or {}
    for key in pairs(panel.AppearanceTable) do panel.AppearanceTable[key] = nil end
    table.CopyFromTo(tbl, panel.AppearanceTable)
end

local function EnsurePresetRow(panel)
    if not IsValid(panel) or panel.__ZcgPresetRow then return end
    panel.__ZcgPresetRow = true

    local row = vgui.Create("DPanel", panel)
    row:Dock(BOTTOM)
    row:SetTall(22)
    row:DockMargin(60, 4, 60, 4)
    function row:Paint(w, h) end

    local function style(btn, bg, line)
        function btn:Paint(w, h)
            draw.RoundedBox(4, 0, 0, w, h, self:IsHovered() and bg or Color(35, 35, 45, 220))
            surface.SetDrawColor(line)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
    end

    local save = vgui.Create("DButton", row)
    save:Dock(LEFT)
    save:SetWide(50)
    save:DockMargin(0, 0, 5, 0)
    save:SetText("Save")
    style(save, Color(30, 150, 35, 255), Color(40, 180, 45, 255))
    local load = vgui.Create("DButton", row)
    load:Dock(LEFT)
    load:SetWide(50)
    load:DockMargin(0, 0, 5, 0)
    load:SetText("Load")
    style(load, Color(50, 100, 180, 255), Color(60, 120, 200, 255))
    local del = vgui.Create("DButton", row)
    del:Dock(LEFT)
    del:SetWide(50)
    del:DockMargin(0, 0, 5, 0)
    del:SetText("Delete")
    style(del, Color(180, 50, 50, 255), Color(200, 60, 60, 255))
    local entry = vgui.Create("DTextEntry", row)
    entry:Dock(FILL)
    entry:SetPlaceholderText("Preset name...")

    function save:DoClick()
        local name = string.gsub(entry:GetValue() or "", "[^%w%s_-]", "")
        if #name < 2 then
            notification.AddLegacy("Enter a preset name (min 2 chars)", NOTIFY_ERROR, 3)
            return
        end
        PresetSave(name, panel.AppearanceTable or {})
        notification.AddLegacy("Preset '" .. name .. "' saved!", NOTIFY_GENERIC, 3)
    end

    function load:DoClick()
        local names = PresetList()
        if #names == 0 then
            notification.AddLegacy("No presets saved yet!", NOTIFY_ERROR, 3)
            return
        end
        local menu = DermaMenu()
        for _, name in ipairs(names) do
            menu:AddOption(name, function()
                local tbl = PresetLoad(name)
                if istable(tbl) then
                    PresetPut(panel, tbl)
                    notification.AddLegacy("Preset '" .. name .. "' loaded!", NOTIFY_GENERIC, 3)
                end
            end)
        end
        menu:Open()
    end

    function del:DoClick()
        local name = entry:GetValue() or ""
        if PresetDelete(name) then
            notification.AddLegacy("Preset '" .. name .. "' deleted!", NOTIFY_HINT, 3)
            entry:SetValue("")
        else
            notification.AddLegacy("Preset not found!", NOTIFY_ERROR, 3)
        end
    end
end

local function PatchLoadAppearanceFile()
    local appearance = GetAppearanceModule()
    if appearance.__DedicatedLoadPatchApplied or not isfunction(appearance.LoadAppearanceFile) then return false end

    appearance.__DedicatedLoadPatchApplied = true

    local oldLoadAppearanceFile = appearance.LoadAppearanceFile
    function appearance.LoadAppearanceFile(...)
        local tbl, reason = oldLoadAppearanceFile(...)
        if istable(tbl) then
            NormalizeAppearanceTable(tbl)
        end

        return tbl, reason
    end

    return true
end

local function PatchAppearancePanelControl()
    local control = vgui.GetControlTable("HG_AppearanceMenu")
    if not istable(control) or control.__DedicatedCompatibilityPatchApplied then return false end

    control.__DedicatedCompatibilityPatchApplied = true

    local oldSetAppearance = control.SetAppearance
    function control:SetAppearance(tbl, ...)
        NormalizeAppearanceTable(tbl)

        if isfunction(oldSetAppearance) then
            return oldSetAppearance(self, tbl, ...)
        end

        self.AppearanceTable = tbl
    end

    local oldPostInit = control.PostInit
    function control:PostInit(...)
        local appearance = GetAppearanceModule()
        local explicit = self.AppearanceTable
        local fromFile = isfunction(appearance.LoadAppearanceFile) and appearance.LoadAppearanceFile(appearance.SelectedAppearance and appearance.SelectedAppearance:GetString() or "main") or nil
        local useExplicit = false

        if istable(explicit) and next(explicit) ~= nil then
            if isfunction(appearance.AppearanceValidater) then
                useExplicit = appearance.AppearanceValidater(explicit)
            else
                useExplicit = true
            end
        end

        self.AppearanceTable = (useExplicit and explicit) or fromFile or (isfunction(appearance.GetRandomAppearance) and appearance.GetRandomAppearance()) or {}
        NormalizeAppearanceTable(self.AppearanceTable)

        local result
        if isfunction(oldPostInit) then
            result = oldPostInit(self, ...)
        end

        NormalizeAppearanceTable(self.AppearanceTable)
        PatchAppearanceViewer(self)
        EnsurePresetRow(self)

        return result
    end

    local oldThink = control.Think
    function control:Think(...)
        NormalizeAppearanceTable(self.AppearanceTable)
        PatchAppearanceViewer(self)
        EnsurePresetRow(self)

        if isfunction(oldThink) then
            return oldThink(self, ...)
        end
    end

    return true
end

hook.Add("Think", PATCH_ID, function()
    PatchLoadAppearanceFile()
    PatchAppearancePanelControl()

    local appearance = GetAppearanceModule()
    local control = vgui.GetControlTable("HG_AppearanceMenu")

    if appearance.__DedicatedLoadPatchApplied and istable(control) and control.__DedicatedCompatibilityPatchApplied then
        hook.Remove("Think", PATCH_ID)
    end
end)

