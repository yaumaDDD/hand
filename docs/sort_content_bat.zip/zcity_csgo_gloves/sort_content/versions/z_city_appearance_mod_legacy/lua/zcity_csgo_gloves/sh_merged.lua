-- Written by build_addon.py. The table files of the other version of a pack that this addon runs in a
-- box and adds to the appearance menu (sh_merge.lua). Empty in a build with that other version.
ZCGloves.Merged = {
}
